# Docker Setup Import

1. Extract this archive on the target machine.
2. Copy    - docker-compose.yml to project root
   - backend.env.example to backend/.env.example
   - admin.env.example to admin/.env.example
3. Create env files from examples (or use backend.env/admin.env if included):
   - cp backend.env.example backend/.env
   - cp admin.env.example admin/.env
4. No image bundle included. On target machine run: docker compose pull
5. Start services:
   - docker compose up -d postgres redis pgadmin
